<?php
	$servername = "localhost";
	$serverusername = "root";
	$serverpassword = "";
	$db = "habyte";
?>